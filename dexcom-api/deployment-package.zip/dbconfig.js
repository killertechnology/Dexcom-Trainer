


  // db.js
  const mysql = require('mysql');
  const connection = mysql.createConnection({
    host: "ec2-52-39-197-130.us-west-2.compute.amazonaws.com",
    user: "root",
    password: "good4you",
    database: "dexcom",
    port: 3306
  });
  
  module.exports = connection;